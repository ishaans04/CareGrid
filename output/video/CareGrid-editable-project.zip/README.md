# CareGrid film source

An editable, deterministic 120-second composition. The supplied voice stems and original score are ready to reuse. No cloud credentials are needed to render.

1. Install Node.js 22+, Google Chrome and FFmpeg (with ffprobe).
2. Run `npm install` in this folder.
3. Put FFmpeg/ffprobe on PATH, or set `FFMPEG_DIR` to the folder containing both executables.
4. Run `npm run preview` for still-frame review, then `npm run render` for the full movie.

Outputs go into `delivery/` beside the renderer. `CAREGRID_FILM_OUTPUT` can select a different output directory. In the original CareGrid repository the renderer reuses its pinned browser dependency.

Edit `story.json` for scene timing and the narration script, and `film.html` for layouts and animation. Changes to spoken words require replacing the corresponding files in `voice/`; their durations are checked against each scene. Run `node render.mjs` without `--skip-audio` to rebuild the audio mix from the stems. The separate SRT is regenerated automatically; phrase timings are estimates within each voice recording.

The movie is rendered from original canvas graphics and real application captures. It is an edited product demonstration, not an unedited real-time screen recording. See PRODUCTION-NOTES.md for source, prediction boundaries and font licenses.

`score.py` reproduces the original music with Python and NumPy (`pip install -r requirements.txt`). It writes score.wav beside the script. There are no external samples.

The FFmpeg executable is not redistributed in this archive.
