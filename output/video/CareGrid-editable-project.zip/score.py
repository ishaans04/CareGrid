import sys,pathlib,wave
root=pathlib.Path(__file__).parent
sys.path.insert(0,str(root.parent/'video/pytools'))
import numpy as np
sr=48000;duration=120;beat=.5
rng=np.random.default_rng(20261121)
audio=np.zeros((duration*sr,2),dtype=np.float32)
def add(at,x,pan=0):
    s=int(at*sr);n=min(len(x),len(audio)-s)
    if s<0 or n<=0:return
    audio[s:s+n,0]+=x[:n]*np.sqrt((1-pan)/2)
    audio[s:s+n,1]+=x[:n]*np.sqrt((1+pan)/2)
def note(at,sec,midi,amp,kind='pluck',pan=0):
    t=np.arange(int(sec*sr),dtype=np.float32)/sr;f=440*2**((midi-69)/12)
    if kind=='pad':env=np.minimum(t/.5,1)*np.minimum((sec-t)/.8,1);x=np.sin(2*np.pi*f*t)+.23*np.sin(2*np.pi*f*2.001*t)
    elif kind=='bass':env=np.minimum(t/.015,1)*np.exp(-t*3);x=np.sin(2*np.pi*f*t)+.14*np.sin(2*np.pi*f*2*t)
    else:env=(1-np.exp(-t*120))*np.exp(-t*5.5);x=np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*f*2*t)+.06*np.sin(2*np.pi*f*5*t)
    add(at,x*env*amp,pan)
def kick(at,amp=.085):
    t=np.arange(int(.19*sr))/sr
    add(at,np.sin(2*np.pi*(48*t+2.3*(1-np.exp(-t*35))))*np.exp(-t*23)*amp)
def hat(at,amp=.014,pan=.3):
    n=int(.07*sr);t=np.arange(n)/sr;z=rng.normal(0,1,n).astype(np.float32);z=np.concatenate(([0],np.diff(z)))
    add(at,z*np.exp(-t*85)*amp,pan)
def clap(at,amp=.025):
    n=int(.11*sr);t=np.arange(n)/sr;z=rng.normal(0,1,n).astype(np.float32);z=np.convolve(z,np.ones(7)/7,mode='same')
    add(at,z*np.exp(-t*36)*amp)
chords=[[50,57,61,66],[47,54,57,62],[43,50,54,59],[45,52,57,64]]
for at in np.arange(.0,13,1):note(at,.8,38,.043,'bass');kick(at,.042)
for i,at in enumerate(np.arange(13,116,2)):
    c=chords[(i//2)%4]
    for j,p in enumerate(c):note(at,3.1,p,.022,'pad',-.55+j*.35)
    for k in range(4):
        tm=at+k*beat
        note(tm,.7,c[0]-12,.065,'bass');kick(tm,.07)
        if k%2:clap(tm,.045)
        hat(tm+.25,.01,-.35 if k%2 else .35)
        for j in range(2):
            p=[c[1]+12,c[2]+12,c[3]+12,c[2]+12][(k*2+j)%4]
            note(tm+j*.25,.65,p,.014,'pluck',-.5 if j else .5)
for at in [6,13,23,31,39,48,55,64,75,83,91,103,111]:
    n=int(.36*sr);t=np.arange(n)/sr;noise=rng.normal(0,1,n).astype(np.float32);noise=np.convolve(noise,np.ones(28)/28,mode='same');add(at-.16,noise*np.sin(np.pi*t/.36)**2*.12)
    note(at,.5,86,.017,'pluck',.15)
for p in [50,57,61,66,74]:note(116,3.9,p,.025,'pad')
delay=int(.1875*sr);audio[delay:,0]+=audio[:-delay,1]*.18;audio[delay:,1]+=audio[:-delay,0]*.15
time=np.arange(len(audio))/sr;env=np.minimum(time/.15,1)*np.minimum((duration-time)/1.8,1);audio*=env[:,None]
audio=np.tanh(audio)
with wave.open(str(root/'score.wav'),'wb')as w:
    w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((audio*32767).astype('<i2').tobytes())
print('Created original 120 BPM, 120-second score.')
