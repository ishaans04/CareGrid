import sys, pathlib, wave, json
sys.path.insert(0,str(pathlib.Path(__file__).parent/'pytools'))
import numpy as np
root=pathlib.Path(__file__).parent
sr=48000; duration=170
rng=np.random.default_rng(217)
audio=np.zeros((duration*sr,2),dtype=np.float32)
def note(at,seconds,midi,gain=0.03,kind='pad',pan=0):
    start=int(at*sr); n=min(int(seconds*sr),len(audio)-start)
    if n<=0:return
    t=np.arange(n,dtype=np.float32)/sr; f=440*2**((midi-69)/12)
    if kind=='pad':
        env=np.minimum(t/1.5,1)*np.minimum((seconds-t)/2.3,1)
        x=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*f*2.002*t)+.12*np.sin(2*np.pi*f*3*t))*env
    elif kind=='pluck':
        env=(1-np.exp(-t*80))*np.exp(-t*3.7)
        x=(np.sin(2*np.pi*f*t)+.23*np.sin(2*np.pi*f*2*t)+.08*np.sin(2*np.pi*f*4*t))*env
    else:
        env=np.minimum(t/.025,1)*np.minimum((seconds-t)/.35,1)
        x=(np.sin(2*np.pi*f*t)+.12*np.sin(2*np.pi*f*2*t))*env
    audio[start:start+n,0]+=x*gain*np.sqrt((1-pan)/2)
    audio[start:start+n,1]+=x*gain*np.sqrt((1+pan)/2)
beat=60/86; bar=beat*4
# Restrained opening pulse; no alarm or medical-monitor imitation.
for at in np.arange(1,25,beat*2): note(at,1.4,38,.025,'bass')
chords=[[50,57,61,66],[47,54,57,62],[43,50,54,59],[45,52,57,62]]
for i,at in enumerate(np.arange(25,165,bar*2)):
    chord=chords[i%4]
    for j,pitch in enumerate(chord):note(at,bar*2+3,pitch,.016,'pad',(-.65+j*.43))
    for at2 in np.arange(at,at+bar*2,beat*2):note(at2,1.25,chord[0]-12,.035,'bass')
    if at>=35:
        for k,at2 in enumerate(np.arange(at,at+bar*2,beat)):
            pitch=[chord[1]+12,chord[2]+12,chord[3]+12,chord[2]+12][k%4]
            note(at2,1.9,pitch,.009 if at<94 else .013,'pluck',(-.4 if k%2 else .4))
    if at>=65:
        for at2 in np.arange(at,at+bar*2,beat*2):
            n=int(.18*sr); tt=np.arange(n)/sr
            kick=np.sin(2*np.pi*(48*tt+2.8*(1-np.exp(-tt*30))))*np.exp(-tt*24)*.035
            s=int(at2*sr)
            if s+n<len(audio):audio[s:s+n]+=kick[:,None]
# One clear resolving chord and a soft tail.
for p in [50,57,61,66,74]:note(157,12.5,p,.016,'pad',0)
# Short transition swells, shaped and low-passed.
for at in [25,35,48,65,80,94,110,130,143,156]:
    n=int(.6*sr); tt=np.arange(n)/sr
    noise=rng.normal(0,1,n).astype(np.float32)
    noise=np.convolve(noise,np.ones(35)/35,mode='same')
    swell=noise*np.sin(np.pi*tt/.6)**2*.05
    s=int((at-.32)*sr);audio[s:s+n,0]+=swell;audio[s:s+n,1]+=swell
# Stereo echo gives the plucks space without sourced samples.
delay=int(beat*.75*sr)
audio[delay:,0]+=audio[:-delay,1]*.16
audio[delay:,1]+=audio[:-delay,0]*.13
t=np.arange(len(audio))/sr
envelope=np.minimum(t/3,1)*np.minimum((duration-t)/4,1)
audio*=envelope[:,None]
audio=np.tanh(audio*1.2)
with wave.open(str(root/'score.wav'),'wb') as w:
    w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr)
    w.writeframes((np.clip(audio,-.95,.95)*32767).astype('<i2').tobytes())
print('Created original 170-second stereo score.')
