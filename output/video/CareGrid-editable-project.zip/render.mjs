import {createRequire} from 'node:module';
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
const dir=path.dirname(fileURLToPath(import.meta.url));
const root=process.env.CAREGRID_REPO_ROOT||path.resolve(dir,'../..');
const inRepo=existsSync(path.join(root,'caregrid_web/package.json'));
const out=process.env.CAREGRID_FILM_OUTPUT||path.join(dir,'delivery');
const require=createRequire(inRepo?path.join(root,'caregrid_web/package.json'):path.join(dir,'package.json'));
const {chromium}=require('@playwright/test');
const suffix=process.platform==='win32'?'.exe':'';
const bin=process.env.FFMPEG_DIR||path.join(root,'tmp/toolchains/ffmpeg/ffmpeg-9.1-essentials_build/bin');
const ffmpeg=existsSync(path.join(bin,'ffmpeg'+suffix))?path.join(bin,'ffmpeg'+suffix):'ffmpeg',probe=existsSync(path.join(bin,'ffprobe'+suffix))?path.join(bin,'ffprobe'+suffix):'ffprobe';
const story=JSON.parse(await readFile(path.join(dir,'story.json'),'utf8'));
await mkdir(out,{recursive:true});await mkdir(path.join(dir,'qa'),{recursive:true});await mkdir(path.join(dir,'voice-edited'),{recursive:true});
const cues=[],voices=[];
for (const s of story.scenes){
 const source=path.join(dir,'voice',s.id+'.wav');
 const rawDuration=Number(execFileSync(probe,['-v','error','-show_entries','format=duration','-of','csv=p=0',source],{encoding:'utf8',windowsHide:true}).trim());
 const speed=Math.max(1.1,rawDuration/(s.end-s.start-.65));
 if(speed>1.5)throw Error('Shorten narration for '+s.id);
 const file=path.join(dir,'voice-edited',s.id+'.wav');
 execFileSync(ffmpeg,['-hide_banner','-v','error','-y','-i',source,'-af',`atempo=${speed.toFixed(5)}`,'-ar','48000',file],{windowsHide:true});
 const duration=Number(execFileSync(probe,['-v','error','-show_entries','format=duration','-of','csv=p=0',file],{encoding:'utf8',windowsHide:true}).trim());
 const start=s.start+.22;
 if(start+duration>s.end-.25)throw Error('Narration overflows '+s.id);
 voices.push({file,duration,start,speed});
 const words=s.text.split(/\s+/);const groups=[];
 for(let i=0;i<words.length;){let end=Math.min(words.length,i+7);for(let j=i+3;j<end;j++)if(/[.?!]$/.test(words[j])){end=j+1;break}groups.push(words.slice(i,end));i=end}
 let offset=0;
 for(const group of groups){const d=duration*group.length/words.length;cues.push({start:start+offset,end:start+offset+d,text:group.join(' ')});offset+=d}
}
await writeFile(path.join(dir,'timing.json'),JSON.stringify({voices,cues},null,2));
function stamp(t){const ms=Math.round(t*1000);return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`}
await writeFile(path.join(out,'CareGrid-Team-Duality.srt'),cues.map((c,i)=>`${i+1}\n${stamp(c.start)} --> ${stamp(c.end)}\n${c.text}\n`).join('\n'));
function run(args){return new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-hide_banner','-y',...args],{windowsHide:true,stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',d=>{log+=d.toString();if(log.length>24000)log=log.slice(-24000)});p.on('error',reject);p.on('close',code=>code===0?resolve(log):reject(Error('FFmpeg '+code+'\n'+log)))})}
if(!process.argv.includes('--skip-audio')){
 const filters=voices.map((v,i)=>`[${i}:a]adelay=delays=${Math.round(v.start*1000)}:all=1[a${i}]`);
 filters.push(voices.map((v,i)=>`[a${i}]`).join('')+`amix=inputs=${voices.length}:normalize=0:duration=longest,apad=whole_dur=${story.duration},atrim=duration=${story.duration},loudnorm=I=-17:TP=-2:LRA=8[narr]`);
 await run([...voices.flatMap(v=>['-i',v.file]),'-filter_complex',filters.join(';'),'-map','[narr]','-ar','48000','-c:a','pcm_s16le',path.join(dir,'narration.wav')]);
 const audioLog=await run(['-i',path.join(dir,'narration.wav'),'-i',path.join(dir,'score.wav'),'-filter_complex','[0:a]asplit=2[vo][duck];[1:a]volume=0.58[m];[m][duck]sidechaincompress=threshold=0.02:ratio=4:attack=25:release=220[bed];[vo][bed]amix=inputs=2:normalize=0:duration=longest,loudnorm=I=-15:TP=-1.5:LRA=8,afade=t=out:st=118:d=2[a]','-map','[a]','-ar','48000','-ac','2','-c:a','pcm_s16le',path.join(dir,'master.wav')]);
 await writeFile(path.join(dir,'audio-mix.log'),audioLog);console.log('Mixed narration and original stereo score.');
}
const mime={'.html':'text/html; charset=utf-8','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2'};
const server=http.createServer(async(req,res)=>{try{let u=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let base=dir;if(u==='/')u='/film.html';if(u.startsWith('/fonts/')){base=existsSync(path.join(dir,'fonts'))?path.join(dir,'fonts'):path.join(root,'caregrid_web/assets/fonts');u=u.slice('/fonts'.length)}else if(u.startsWith('/brand/')){base=existsSync(path.join(dir,'brand'))?path.join(dir,'brand'):path.join(root,'caregrid_web/assets');u=u.slice('/brand'.length)}const target=path.resolve(base,'.'+u);if(!target.startsWith(base+path.sep))throw Error('Forbidden');res.setHeader('content-type',mime[path.extname(target)]||'application/octet-stream');res.end(await readFile(target))}catch(e){res.statusCode=404;res.end('Missing')}});
await new Promise(resolve=>server.listen(4808,'127.0.0.1',resolve));
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1920,height:1080}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:4808');const ready=await page.evaluate(()=>window.ready);console.log(JSON.stringify(ready));
 const samples=[1.5,4.5,9,16,20,26,29,35,42,46,51,58,62,67,72,78,81,87,95,100,107,115];
 for(const [i,t]of samples.entries()){
   await page.evaluate(t=>window.render(Math.round(t*60)),t);
   const b64=await page.evaluate(()=>document.querySelector('canvas').toDataURL('image/png').split(',')[1]);
   await writeFile(path.join(dir,'qa',String(i+1).padStart(2,'0')+'-'+t+'.png'),Buffer.from(b64,'base64'));
   if(t===115){await page.evaluate(()=>window.render(6900,false));const poster=await page.evaluate(()=>document.querySelector('canvas').toDataURL('image/png').split(',')[1]);await writeFile(path.join(out,'CareGrid-poster.png'),Buffer.from(poster,'base64'))}
 }
 if(errors.length)throw Error(errors.join('\n'));
 if(!process.argv.includes('--preview')){
   const draft=process.argv.includes('--draft');const fps=draft?15:30;const scale=draft?960:1920;
   const silent=path.join(dir,draft?'draft-silent.mp4':'final-silent.mp4');
   const encoder=spawn(ffmpeg,['-hide_banner','-y','-f','image2pipe','-framerate',String(fps),'-vcodec','mjpeg','-i','pipe:0','-an','-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:v','libx264','-preset','veryfast','-crf',draft?'23':'18','-pix_fmt','yuv420p','-r',String(fps),'-threads','6',silent],{windowsHide:true,stdio:['pipe','ignore','pipe']});
   let encLog='';encoder.stderr.on('data',d=>{encLog+=d.toString();if(encLog.length>20000)encLog=encLog.slice(-20000)});encoder.on('error',e=>console.error(e));
   const completed=new Promise((resolve,reject)=>encoder.on('close',code=>code===0?resolve():reject(Error(encLog))));
   const count=Math.round(story.duration*fps);const start=Date.now();
   for(let f=0;f<count;f+=12){
     const data=await page.evaluate(({start,count,fps,scale})=>{const canvas=document.querySelector('canvas');let target=canvas;if(scale!==1920){target=document.createElement('canvas');target.width=scale;target.height=scale*1080/1920}const result=[];for(let i=0;i<count;i++){window.render(Math.round((start+i)/fps*60));if(target!==canvas)target.getContext('2d').drawImage(canvas,0,0,target.width,target.height);result.push(target.toDataURL('image/jpeg',.97).split(',')[1])}return result},{start:f,count:Math.min(12,count-f),fps,scale});
     for(const b64 of data)if(!encoder.stdin.write(Buffer.from(b64,'base64')))await once(encoder.stdin,'drain');
     if(f%(fps*10)<12)console.log(`Rendered ${Math.min(count,f+12)}/${count} frames · ${Math.round((Date.now()-start)/1000)}s elapsed`);
   }
   encoder.stdin.end();await completed;await writeFile(path.join(dir,'video-encode.log'),encLog);
   const target=draft?path.join(dir,'CareGrid-draft.mp4'):path.join(out,'CareGrid-Team-Duality.mp4');
   await run(['-i',silent,'-i',path.join(dir,'master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',String(story.duration),'-movflags','+faststart','-metadata','title=CareGrid — Every second, accounted for.','-metadata','artist=Team Duality — Ishaan Sharma and Hriday Vig','-metadata','comment=Working prototype; fictional campus data. Readiness figures are predictions, not field outcomes. Synthesized narration and original procedural score.',target]);
   console.log(`Exported ${target} (${(await stat(target)).size} bytes)`);
 }
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
